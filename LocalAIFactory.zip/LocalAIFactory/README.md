# LocalAIFactory

A **private, local-first AI software-engineering assistant** for .NET / MSSQL / EF Core / Python / SQL / IIS and banking middleware (BDM, MCIB, ChequeXpert/Parascript, ETAMS). It is **not** a generic chatbot: its core value is a **persistent, curated project memory** with an approval lifecycle. Approved knowledge, code and business rules are injected **first** into every prompt, so answers are grounded in *your* systems.

It runs entirely on your machine by default (Ollama + SQL Server + optional Qdrant), and degrades gracefully: if Ollama or Qdrant are down, the app still runs and falls back to MSSQL keyword search.

> **Build note:** this solution was assembled file-by-file and has **not** been compiled in the authoring environment (no .NET 10 SDK / NuGet access there). The first `dotnet build` (or opening it in Visual Studio and building) is the verification step.

---

## What it does

- **Project ingestion** — upload a project `.zip`; it is extracted and processed in the background through a resilient pipeline: extract → scan → classify → store → chunk → embed → profile → graph → candidate rules. Optional stages are wrapped so they never fail the import.
- **Knowledge extraction & RAG** — files become knowledge items, chunked and embedded into Qdrant (or keyword-indexed in MSSQL). Retrieval is **approved-first**.
- **Business rules & approved code** — promote useful answers/snippets to reusable, approved memory.
- **ChatGPT / Claude import** — import `conversations.json` (ChatGPT) or a Claude export; transcripts are indexed and fenced code blocks become reviewable candidates.
- **Lightweight knowledge graph** — heuristic + model-suggested entities/relationships (no Neo4j), reviewable and approvable.
- **Task-Profile model routing** — every task type routes to a primary model, with optional validation and comparison models.
- **Workspace Management (Phase 1 scaffolding)** — working copies of imported projects, snapshots, and proposed-change history, ready for Phase 2 autonomous editing.

---

## Model strategy: Task Profiles (single-model-first)

Instead of fixed "roles", each **TaskType** (Chat, ProjectImport, CodeGeneration, SqlAnalysis, …) has a **TaskProfile** that selects:

- a **primary** model (required),
- an optional **validation** model (a strict reviewer pass),
- an optional **comparison** model (stored side-by-side for later review),
- RAG flags (project memory / knowledge base / knowledge graph),
- temperature, max tokens, `LocalOnly`, and `RequireApprovalBeforeCloudUse`.

**Single-model operation is the guaranteed baseline.** The seed data creates **one** local model (`qwen2.5-coder:14b`, embeddings `nomic-embed-text`) and points every profile's primary at it, with validation/comparison off. The router fallback chain is: *profile primary → system default enabled model → any enabled model → "no model configured"*.

Cloud models (OpenAI, OpenAI-compatible, Claude) are only ever used when you add one with an API key and either select it explicitly in chat or enable cloud for a profile. `LocalOnly` blocks cloud entirely; missing keys are skipped gracefully. The **chat model dropdown** is a per-turn override, and choosing a cloud model there counts as consent.

---

## Architecture (8 projects, no dependency cycles)

```
Core  ──────────────► (no dependencies: entities, enums, DTOs, interfaces, options)
Data  ──► Core         (EF Core DbContext, migrations, seeder, Data Protection, audit)
Rag   ──► Core, Data   (chunking, embeddings, Qdrant REST, keyword fallback, approved-first context builder, approval)
Agent ──► Core, Data, Rag   (chat providers, model router, task-profile resolver, the single execution service, chat orchestrator)
Workspaces ──► Core, Data    (safe zip extraction, workspace manager/snapshots/changes, diff, disabled git/build stubs)
Terminal   ──► Core          (command policy + disabled terminal service)
Ingestion  ──► Core, Data, Rag, Agent, Workspaces   (zip pipeline, classifier, profiler, knowledge graph, file & conversation import)
Web        ──► all           (ASP.NET Core MVC UI, controllers, background ingestion worker)
```

Notes: Qdrant is accessed over its **REST API** (no gRPC). Global knowledge uses `projectId = 0` in the payload. Markdown is rendered client-side (marked.js) and Bootstrap 5 is via CDN. The background ingestion worker is hosted in the Web project.

---

## Prerequisites

- **.NET 10 SDK**
- **SQL Server** — LocalDB or SQL Express is fine (default connection targets `(localdb)\MSSQLLocalDB`)
- **Ollama** (recommended, for local chat + embeddings) — https://ollama.com
- **Qdrant** (optional, for vector search) — Docker image `qdrant/qdrant`
- Optional: **OpenAI** and/or **Anthropic Claude** API keys for cloud models

---

## Getting started

1. **Restore & build**
   ```
   dotnet build LocalAIFactory.sln
   ```
   (or open `LocalAIFactory.sln` in Visual Studio 2022+/Rider and build)

2. **Pull local models** (optional but recommended)
   ```
   ./scripts/setup-ollama.ps1
   ```

3. **Start Qdrant** (optional — keyword search is used if absent)
   ```
   ./scripts/start-qdrant-docker.ps1
   ```

4. **Configure the database** — the app **migrates and seeds automatically on startup**. To do it manually:
   ```
   ./scripts/create-dev-db.ps1
   ```

5. **Run** the `LocalAIFactory.Web` project and open the dashboard. Adjust settings in `src/LocalAIFactory.Web/appsettings.json` (connection string, Ollama URL/model, Qdrant, embedding provider).

---

## Typical first run (e.g. bringing up BDM)

1. **Projects** — the seeder creates BDM, MCIB, CHEQUEXPERT, ETAMS, SQL_LIB, METABASE_LIB, DEPLOY_LIB and a GLOBAL project. Add more as needed.
2. **Import Project** — upload the BDM `.zip`. Watch the status page; it processes in the background.
3. **Knowledge / Rules / Graph** — review the generated knowledge items, candidate business rules and graph entities; **approve** the correct ones. Approved items are retrieved first.
4. **Chat** — pick the BDM project (and optionally a model) and ask questions; answers are grounded in approved BDM memory.
5. **Save** good answers back as **Knowledge / Approved code / Business rule** to strengthen the memory loop.

---

## Configuring cloud models (optional)

Under **Config → Models → Add a model**, choose provider **OpenAi**, **OpenAiCompatible**, or **Claude**, set the base URL and model name, and paste the API key (stored encrypted via ASP.NET Data Protection). Use **Test** to verify connectivity. Then either select it in the chat dropdown or point a Task Profile's primary/validation/comparison at it.

- OpenAI: base URL `https://api.openai.com/v1`
- Claude: base URL `https://api.anthropic.com`
- OpenAI-compatible (LM Studio, vLLM, etc.): your local server's base URL

---

## Workspace Management — Phase 1 scope and Phase 2 vision

The long-term goal is to **enhance, debug, fix and evolve** imported projects (BDM, MCIB, ChequeXpert, ETAMS). The schema and surfaces for that are in place now, **without** enabling autonomous editing yet.

**Phase 1 (included, enabled):**
- Entities: `Workspace`, `WorkspaceSnapshot`, `WorkspaceChange`, `WorkspaceFile`.
- A workspace is a working copy of a project (Original Import, v23, v24…); it records a file inventory from the import.
- Snapshots act as lightweight source control (taken before AI modifications).
- Changes capture file + previous/new content + reason + prompt + model + date — your debugging history.
- Disabled-by-default task profiles: **CodeModification**, **BuildAnalysis**, **WorkspacePlanning**.
- A line-based **diff** preview and a read-only **build** service stub.

**Phase 2 (prepared, not enabled):** the intended flow is — user asks ("Add claim response API") → system identifies files → creates a snapshot → proposes modifications → user approves → system edits files → shows a diff → runs the build → stores the successful fix as approved knowledge. Applying changes to disk currently throws by design (`WorkspaceModificationService.ApplyChangeAsync`) so the surface exists without behavior.

---

## Limitations (Phase 1)

- **Not compiled here** — first `dotnet build` is the verification step.
- **No authentication** — intended for local/trusted use; audit logs use a fixed `local` user.
- **Heuristic token counts** — `EstimateTokens` ≈ chars/4 (not a real tokenizer).
- **Terminal execution disabled** — command policy is enforced, but nothing actually runs.
- **Workspace apply disabled** — proposing/recording changes works; writing to disk and building is Phase 2.
- **Knowledge-graph & profiling are heuristic** when no model is available; richer extraction needs a configured model.

---

## Swapping the default model & roadmap

To change the baseline model, edit the seed in `src/LocalAIFactory.Data/DbSeeder.cs` (or add a model in the UI and **Set default**). Because every profile falls back to the default enabled model, one change updates all tasks. The Phase 2 roadmap centers on enabling the workspace editing flow described above behind the already-present task profiles and services.
