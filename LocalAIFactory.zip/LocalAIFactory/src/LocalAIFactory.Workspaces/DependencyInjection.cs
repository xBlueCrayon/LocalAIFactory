using LocalAIFactory.Core.Abstractions;
using LocalAIFactory.Workspaces.Management;
using Microsoft.Extensions.DependencyInjection;

namespace LocalAIFactory.Workspaces;

public static class DependencyInjection
{
    public static IServiceCollection AddLocalAIFactoryWorkspaces(this IServiceCollection services)
    {
        // File-system helpers (stateless): singletons.
        services.AddSingleton<IZipExtractionService, ZipExtractionService>();
        services.AddSingleton<IWorkspaceService, WorkspaceService>();
        services.AddSingleton<IGitService, DisabledGitService>();
        services.AddSingleton<IBuildService, DisabledBuildService>();
        services.AddSingleton<IDiffService, DiffService>();

        // Workspace management (uses DbContext): scoped.
        services.AddScoped<IWorkspaceManager, WorkspaceManager>();
        services.AddScoped<IWorkspaceSnapshotService, WorkspaceSnapshotService>();
        services.AddScoped<IWorkspaceModificationService, WorkspaceModificationService>();

        return services;
    }
}
