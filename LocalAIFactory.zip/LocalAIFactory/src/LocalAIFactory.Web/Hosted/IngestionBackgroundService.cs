using LocalAIFactory.Core.Abstractions;

namespace LocalAIFactory.Web.Hosted;

// Drains the ingestion queue in the background, processing each ZIP import job in its own DI scope.
public sealed class IngestionBackgroundService : BackgroundService
{
    private readonly IIngestionQueue _queue;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<IngestionBackgroundService> _log;

    public IngestionBackgroundService(IIngestionQueue queue, IServiceScopeFactory scopeFactory, ILogger<IngestionBackgroundService> log)
    {
        _queue = queue; _scopeFactory = scopeFactory; _log = log;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var jobId in _queue.DequeueAllAsync(stoppingToken))
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var svc = scope.ServiceProvider.GetRequiredService<IProjectIngestionService>();
                await svc.ProcessJobAsync(jobId, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception ex) { _log.LogError(ex, "Ingestion job {Id} crashed in background worker", jobId); }
        }
    }
}
