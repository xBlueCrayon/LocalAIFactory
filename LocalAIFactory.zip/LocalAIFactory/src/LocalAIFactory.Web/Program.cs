using LocalAIFactory.Agent;
using LocalAIFactory.Data;
using LocalAIFactory.Ingestion;
using LocalAIFactory.Rag;
using LocalAIFactory.Terminal;
using LocalAIFactory.Web.Hosted;
using LocalAIFactory.Workspaces;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient();

// Persist Data Protection keys so encrypted API keys survive restarts.
var keysDir = Path.Combine(builder.Environment.ContentRootPath, "keys");
Directory.CreateDirectory(keysDir);
builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(keysDir))
    .SetApplicationName("LocalAIFactory");

// Application modules.
builder.Services.AddLocalAIFactoryData(builder.Configuration);
builder.Services.AddLocalAIFactoryRag(builder.Configuration);
builder.Services.AddLocalAIFactoryAgent();
builder.Services.AddLocalAIFactoryIngestion();
builder.Services.AddLocalAIFactoryWorkspaces();
builder.Services.AddLocalAIFactoryTerminal();

builder.Services.AddHostedService<IngestionBackgroundService>();

var app = builder.Build();

// Apply migrations and seed baseline data (projects, one local model, task profiles).
using (var scope = app.Services.CreateScope())
{
    var sp = scope.ServiceProvider;
    var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger("Startup");
    try
    {
        var db = sp.GetRequiredService<AppDbContext>();
        db.Database.Migrate();
        await DbSeeder.SeedAsync(db);
        logger.LogInformation("Database migrated and seeded.");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Database initialization failed. Check the connection string and that SQL Server/LocalDB is running.");
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
