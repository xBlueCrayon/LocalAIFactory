using LocalAIFactory.Core.Abstractions;
using LocalAIFactory.Core.ViewModels;
using LocalAIFactory.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LocalAIFactory.Web.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;
    private readonly IVectorStore _vector;
    private readonly IEmbeddingService _embedding;

    public HomeController(AppDbContext db, IVectorStore vector, IEmbeddingService embedding)
    {
        _db = db; _vector = vector; _embedding = embedding;
    }

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        bool qdrant;
        try { qdrant = await _vector.HealthAsync(ct); } catch { qdrant = false; }

        var activeModel = await _db.ModelConfigurations
            .Where(m => m.IsEnabled).OrderByDescending(m => m.IsDefault)
            .Select(m => m.Name).FirstOrDefaultAsync(ct);

        var vm = new DashboardViewModel
        {
            Projects = await _db.Projects.CountAsync(ct),
            KnowledgeItems = await _db.KnowledgeItems.CountAsync(ct),
            ApprovedKnowledge = await _db.KnowledgeItems.CountAsync(k => k.IsApproved, ct),
            ApprovedCode = await _db.ApprovedCodeSnippets.CountAsync(ct),
            BusinessRules = await _db.BusinessRules.CountAsync(ct),
            ChatSessions = await _db.ChatSessions.CountAsync(ct),
            ImportedFiles = await _db.ImportedFiles.CountAsync(ct),
            ModelConfigurations = await _db.ModelConfigurations.CountAsync(ct),
            ActiveModel = activeModel,
            QdrantHealthy = qdrant,
            EmbeddingsConfigured = _embedding.IsConfigured
        };
        return View(vm);
    }

    public IActionResult Error() => View();
}
