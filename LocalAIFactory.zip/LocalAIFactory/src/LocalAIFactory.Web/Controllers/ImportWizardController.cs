using LocalAIFactory.Core.Abstractions;
using LocalAIFactory.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LocalAIFactory.Web.Controllers;

public class ImportWizardController : Controller
{
    private readonly AppDbContext _db;
    private readonly IProjectIngestionService _ingestion;
    private readonly IIngestionQueue _queue;

    public ImportWizardController(AppDbContext db, IProjectIngestionService ingestion, IIngestionQueue queue)
    {
        _db = db; _ingestion = ingestion; _queue = queue;
    }

    public async Task<IActionResult> Index(CancellationToken ct)
    {
        ViewBag.Projects = await _db.Projects.OrderBy(p => p.Name).ToListAsync(ct);
        ViewBag.Jobs = await _db.IngestionJobs.AsNoTracking().OrderByDescending(j => j.Id).Take(20).ToListAsync(ct);
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(524288000)]
    public async Task<IActionResult> Start(int? projectId, IFormFile? zip, CancellationToken ct)
    {
        if (zip is null || zip.Length == 0) { TempData["Error"] = "Choose a .zip file."; return RedirectToAction(nameof(Index)); }
        using var ms = new MemoryStream();
        await zip.CopyToAsync(ms, ct);
        var jobId = await _ingestion.CreateZipJobAsync(projectId, zip.FileName, ms.ToArray(), ct);
        await _queue.EnqueueAsync(jobId, ct);
        TempData["Message"] = "Import started. This page refreshes as it progresses.";
        return RedirectToAction(nameof(Status), new { jobId });
    }

    public async Task<IActionResult> Status(int jobId, CancellationToken ct)
    {
        var job = await _db.IngestionJobs.AsNoTracking().FirstOrDefaultAsync(j => j.Id == jobId, ct);
        if (job is null) return RedirectToAction(nameof(Index));
        return View(job);
    }

    [HttpGet]
    public async Task<IActionResult> Progress(int jobId, CancellationToken ct)
    {
        var p = await _ingestion.GetProgressAsync(jobId, ct);
        if (p is null) return NotFound();
        return Json(new
        {
            status = p.Status.ToString(),
            phase = p.Phase.ToString(),
            total = p.TotalFiles,
            processed = p.ProcessedFiles,
            skipped = p.SkippedFiles,
            chunks = p.ChunkCount,
            embedded = p.EmbeddedCount,
            error = p.Error
        });
    }
}
