using LocalAIFactory.Core.Dtos;
using LocalAIFactory.Core.Entities;

namespace LocalAIFactory.Core.ViewModels;

public sealed class DashboardViewModel
{
    public int Projects { get; set; }
    public int KnowledgeItems { get; set; }
    public int ApprovedKnowledge { get; set; }
    public int ApprovedCode { get; set; }
    public int BusinessRules { get; set; }
    public int ChatSessions { get; set; }
    public int ImportedFiles { get; set; }
    public int ModelConfigurations { get; set; }
    public string? ActiveModel { get; set; }
    public bool QdrantHealthy { get; set; }
    public bool EmbeddingsConfigured { get; set; }
}

public sealed class ChatPageViewModel
{
    public List<Project> Projects { get; set; } = new();
    public List<ModelConfiguration> Models { get; set; } = new();
    public List<ChatSession> Sessions { get; set; } = new();
    public ChatSession? CurrentSession { get; set; }
    public List<ChatMessage> Messages { get; set; } = new();
    public int? SelectedProjectId { get; set; }
    public int? SelectedModelId { get; set; }
}

public sealed class ChatSendViewModel
{
    public int? SessionId { get; set; }
    public int? ProjectId { get; set; }
    public int? ModelConfigurationId { get; set; }
    public string Message { get; set; } = "";
}

public sealed class SaveResponseViewModel
{
    public int MessageId { get; set; }
    public int? ProjectId { get; set; }
    public string Title { get; set; } = "";
    public string Target { get; set; } = "Knowledge"; // Knowledge | ApprovedCode | BusinessRule
    public string? Language { get; set; }
    public string? Framework { get; set; }
}
