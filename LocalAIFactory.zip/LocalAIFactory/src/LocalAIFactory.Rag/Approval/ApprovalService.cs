using LocalAIFactory.Core.Abstractions;
using LocalAIFactory.Core.Entities;
using LocalAIFactory.Core.Enums;
using LocalAIFactory.Data;
using Microsoft.EntityFrameworkCore;

namespace LocalAIFactory.Rag.Approval;

// Approval is the learning loop: flip status, audit, and re-index so the item is retrieved first.
public sealed class ApprovalService : IApprovalService
{
    private readonly AppDbContext _db;
    private readonly IKnowledgeIndexer _indexer;
    private readonly IAuditService _audit;

    public ApprovalService(AppDbContext db, IKnowledgeIndexer indexer, IAuditService audit)
    {
        _db = db; _indexer = indexer; _audit = audit;
    }

    public async Task ApproveKnowledgeItemAsync(int knowledgeItemId, CancellationToken ct = default)
    {
        var item = await _db.KnowledgeItems.FirstOrDefaultAsync(k => k.Id == knowledgeItemId, ct);
        if (item is null) return;
        item.Status = KnowledgeStatus.Approved;
        item.IsApproved = true;
        item.IsDeprecated = false;
        item.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync("ApproveKnowledgeItem", nameof(KnowledgeItem), item.Id.ToString(), item.Title, ct);
        await _indexer.IndexKnowledgeItemAsync(item.Id, ct);
    }

    public async Task DeprecateKnowledgeItemAsync(int knowledgeItemId, CancellationToken ct = default)
    {
        var item = await _db.KnowledgeItems.FirstOrDefaultAsync(k => k.Id == knowledgeItemId, ct);
        if (item is null) return;
        item.Status = KnowledgeStatus.Deprecated;
        item.IsApproved = false;
        item.IsDeprecated = true;
        item.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync("DeprecateKnowledgeItem", nameof(KnowledgeItem), item.Id.ToString(), item.Title, ct);
    }

    public async Task ApproveBusinessRuleAsync(int businessRuleId, CancellationToken ct = default)
    {
        var rule = await _db.BusinessRules.FirstOrDefaultAsync(r => r.Id == businessRuleId, ct);
        if (rule is null) return;
        rule.Status = BusinessRuleStatus.Approved;
        rule.IsApproved = true;
        rule.ApprovedUtc = DateTime.UtcNow;
        rule.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync("ApproveBusinessRule", nameof(BusinessRule), rule.Id.ToString(), rule.Title, ct);
    }

    public async Task ApproveCodeSnippetAsync(int approvedCodeSnippetId, CancellationToken ct = default)
    {
        var snip = await _db.ApprovedCodeSnippets.FirstOrDefaultAsync(s => s.Id == approvedCodeSnippetId, ct);
        if (snip is null) return;
        snip.IsReusable = true;
        snip.ApprovedUtc = DateTime.UtcNow;
        snip.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync("ApproveCodeSnippet", nameof(ApprovedCodeSnippet), snip.Id.ToString(), snip.Title, ct);
    }

    public async Task<int> PromoteCodeBlockAsync(int extractedCodeBlockId, string title, CancellationToken ct = default)
    {
        var block = await _db.ExtractedCodeBlocks.FirstOrDefaultAsync(b => b.Id == extractedCodeBlockId, ct);
        if (block is null) return 0;

        var snippet = new ApprovedCodeSnippet
        {
            ProjectId = block.ProjectId,
            Title = string.IsNullOrWhiteSpace(title) ? "Promoted code block" : title,
            Language = string.IsNullOrWhiteSpace(block.Language) ? "text" : block.Language!,
            Content = block.Content ?? "",
            Explanation = "Promoted from an extracted code block.",
            SourceReference = "ExtractedCodeBlock #" + block.Id,
            IsReusable = true,
            ApprovedUtc = DateTime.UtcNow
        };
        _db.ApprovedCodeSnippets.Add(snippet);
        block.Status = KnowledgeStatus.Approved;
        await _db.SaveChangesAsync(ct);

        block.PromotedToApprovedCodeSnippetId = snippet.Id;
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync("PromoteCodeBlock", nameof(ApprovedCodeSnippet), snippet.Id.ToString(), snippet.Title, ct);
        return snippet.Id;
    }

    public async Task ApproveProjectProfileSectionAsync(int sectionId, CancellationToken ct = default)
    {
        var section = await _db.ProjectProfileSections.FirstOrDefaultAsync(s => s.Id == sectionId, ct);
        if (section is null) return;
        section.Status = KnowledgeStatus.Approved;
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync("ApproveProjectProfileSection", nameof(ProjectProfileSection), section.Id.ToString(), section.Title, ct);
    }
}
